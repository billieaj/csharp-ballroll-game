﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraFollow : MonoBehaviour
{

	public GameObject Target;
	public Vector3 Offset = new Vector3 (0, 10, -20);

	// Use this for initialization
	void Start ()
	{
		
	}

	// Update is called once per frame
	void Update ()
	{
		transform.position = Target.transform.position + Offset;
		transform.LookAt (Target.transform.position);
	}
}
