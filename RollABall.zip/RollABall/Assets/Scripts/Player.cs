﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

// Move the player
public class Player : MonoBehaviour
{

	Rigidbody rb;
	public float forcemultiplier = 10f;
	public int Score = 0;
	public Text ScoreText;
	public Text WinText;
	public Text QuitText;

	// Use this for initialization
	void Start ()
	{
		rb = GetComponent<Rigidbody> ();
		WinText.text = "";
		QuitText.text = "";
	}
	
	// Update is called once per frame
	void Update ()
	{
		float xinput = Input.GetAxis ("Horizontal") * forcemultiplier;
		float zinput = Input.GetAxis ("Vertical") * forcemultiplier;
		rb.AddForce (xinput, 0, zinput);
		ScoreText.text = "Score: " + Score.ToString ();
		if (Score >= 10) {
			WinText.text = "You win!";
			QuitText.text = "Press esc key to exit.";
			if (Input.GetKey ("escape")) {
				Application.Quit ();
			}
		}
	}

	// When collectable is collected
	void Collected ()
	{
		Score++;
	}
}
